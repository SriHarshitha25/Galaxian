import pygame

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.image.load('assets/enemy.png')
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = 1

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > 600:
            self.rect.bottom = 0

    def draw(self, screen):
        screen.blit(self.image, self.rect.topleft)
