import pygame
import sys
from player import Player
from enemy import Enemy
from bullet import Bullet

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Galactic Defenders')

# Load sounds
shoot_sound = pygame.mixer.Sound('sounds/shoot.wav')
explosion_sound = pygame.mixer.Sound('sounds/explosion.wav')

# Colors
BLACK = (0, 0, 0)

# Player
player = Player(WIDTH // 2, HEIGHT - 50)

# Enemies
enemies = [Enemy(x, 50) for x in range(100, WIDTH - 100, 100)]

# Bullets
bullets = []

# Main game loop
running = True
while running:
    screen.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                bullet = Bullet(player.rect.centerx, player.rect.top)
                bullets.append(bullet)
                shoot_sound.play()

    keys = pygame.key.get_pressed()
    player.update(keys)

    for bullet in bullets[:]:
        bullet.update()
        if bullet.rect.bottom < 0:
            bullets.remove(bullet)
        else:
            for enemy in enemies[:]:
                if bullet.rect.colliderect(enemy.rect):
                    enemies.remove(enemy)
                    bullets.remove(bullet)
                    explosion_sound.play()
                    break

    for enemy in enemies:
        enemy.update()

    player.draw(screen)
    for bullet in bullets:
        bullet.draw(screen)
    for enemy in enemies:
        enemy.draw(screen)

    pygame.display.flip()
    pygame.time.Clock().tick(60)

pygame.quit()
sys.exit()
